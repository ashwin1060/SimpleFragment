﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.IO;
using System.Web.Script.Serialization;

namespace JSONWebService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {

        public int AddReservation(Stream JSONDataStream)
        {
            try
            {
                // Read in our Stream into a string
                StreamReader reader = new StreamReader(JSONDataStream);
                string JSONdata = reader.ReadToEnd();

                //..then conver the string into a single "wsReservation" record.
                JavaScriptSerializer jss = new JavaScriptSerializer();
                wsReservations res = jss.Deserialize<wsReservations>(JSONdata);
                wsUser usr = jss.Deserialize<wsUser>(JSONdata);

                if(res == null)
                {
                    // Error: Deserialization failed
                    return -2;
                }

                TestDBDataContext dc = new TestDBDataContext();
                List<wsReservations> newRes = new List<wsReservations>();
                List<wsUser> newUser = new List<wsUser>();

                Table_User NewUser = dc.Table_Users.Where(s => s.id != usr.userID);

                newRes.Add(new wsReservations()
                {
                    ReservationID = res.ReservationID,
                    UserID = res.UserID,
                    RDate = res.RDate,
                    RTime = res.RTime,
                    GuestCount = res.GuestCount,
                    RPrefs = res.RPrefs
                });

                newUser.Add(new wsUser() 
                {
                    userID = usr.userID,
                    FName = usr.FName,
                    LName = usr.LName,
                    Email = usr.Email,
                    Phone = usr.Phone

                });

                return 0;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return -1;
            }
        }

        public int UpdateReservation(Stream JSONdataStream)
        {
            try
            {
                // Read in our Stream into a string...
                StreamReader reader = new StreamReader(JSONdataStream);
                string JSONdata = reader.ReadToEnd();

                // ..then convert the string into a single "wsReservation" record.
                JavaScriptSerializer jss = new JavaScriptSerializer();
                wsReservations res = jss.Deserialize<wsReservations>(JSONdata);
                if (res == null)
                {
                    // Error: Couldn't deserialize our JSON string into a "wsReservations" object.
                    return -2;
                }

                TestDBDataContext dc = new TestDBDataContext();
                Table_UserReservation currentRes = dc.Table_UserReservations.Where(o => o.ReservationID == res.ReservationID).FirstOrDefault();
                if (currentRes == null)
                {
                    // Couldn't find reservation
                    return -3;
                }

                // Update our SQL Server [Order] record, with our new Shipping Details (send from whatever
                // app is calling this web service)
                currentRes.Date = res.RDate;
                currentRes.Time = res.RTime;
                currentRes.GuestCount = res.GuestCount;
                currentRes.Prefrences = res.RPrefs;

                dc.SubmitChanges();

                return 0;     // Success !
            }
            catch (Exception e)
            {
                return -1;
            }
        }

        //public List<wsReservations> GetReservations(long ReservationID)
        //{
        //    TestDBDataContext dc = new TestDBDataContext();
        //    List<wsReservations> results = new List<wsReservations>();
        //    System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.GetCultureInfo("en-US");


        //    foreach (Table_UserReservation r in dc.Table_UserReservations.Where(s => s.ReservationID == ReservationID))
        //    {
        //        results.Add(new wsReservations()
        //        {
        //            ReservationID = r.ReservationID,
        //            UserID = r.UserID,
        //            RDate = r.Date,
        //            RTime = r.Time,
        //            GuestCount = r.GuestCount,
        //            RPrefs = r.Prefrences
        //        });
        //    }

        //    return results;
        //}

        public List<wsCustomer> GetAllCustomers()
        {
            TestDBDataContext dc = new TestDBDataContext();
            List<wsCustomer> results = new List<wsCustomer>();

            foreach (Table_User cust in dc.Table_Users)
            {
                results.Add(new wsCustomer()
                {
                    CustomerID = cust.id,
                    CustomerFName = cust.FirstName,
                    CustomerLName = cust.LastName,
                    CustomerEmail = cust.Email,
                    CustomerPhone = cust.Phone
                });
            }

            return results;
        }

        public string GetData(string value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}

