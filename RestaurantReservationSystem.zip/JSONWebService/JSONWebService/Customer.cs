﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;



namespace JSONWebService
{

    [DataContract]
    public class wsCustomer
    {
        [DataMember]
        public int CustomerID { get; set; }

        [DataMember]
        public string CustomerFName { get; set; }

        [DataMember]
        public string CustomerLName { get; set; }

        [DataMember]
        public string CustomerEmail { get; set; }

        [DataMember]
        public string CustomerPhone { get; set; }

    }

}