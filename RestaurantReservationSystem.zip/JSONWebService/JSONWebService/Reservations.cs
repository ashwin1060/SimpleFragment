﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;


namespace JSONWebService
{
    [DataContract]
    [Serializable]
    public class wsReservations
    {
        [DataMember]
        public long ReservationID { get; set; }
        
        [DataMember]
        public int UserID { get; set; }
        
        [DataMember]
        public string RDate { get; set; }

        [DataMember]
        public string RTime { get; set; }
        
        [DataMember]
        public int GuestCount { get; set; }

        [DataMember]
        public string RPrefs { get; set; }
    }

    [DataContract]
    [Serializable]
    public class wsUser
    {
        [DataMember]
        public int userID { get; set; }
        
        [DataMember]
        public string FName { get; set; }

        [DataMember]
        public string LName { get; set; }
        
        [DataMember]
        public string Email { get; set; }

        [DataMember]
        public string Phone { get; set; }
    }
}